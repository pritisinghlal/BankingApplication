package com.mybankingapp;

import java.util.Scanner;

public class CurrentAccount implements Bank{
	
	 private  float amount;
	   private float balance;
	
	
	public CurrentAccount(float amount, float balance) {
		super();
		this.amount = amount;
		this.balance = balance;
	}
	

	@Override
	public String toString() {
		return "CurrentAccount [amount=" + amount + ", balance=" + balance + "]";
	}


	@Override
	public void transferFund() {
  
		
	}

//	@Override
//	public void withdrawFund() {
//		
//		Scanner input = new Scanner(System.in);
//		
//			System.out.println("Your Balance=" + balance);
//			System.out.print("Enter amount to withdraw:");
//			amount = input.nextInt();
//			if (balance < amount) {
//				System.out.println("Not sufficient balance.");
//				
//			}
//			if (amount < 0) {
//				System.out.println("Invalid Amount");
//				
//			}
//			balance = balance - amount;
//			
//	}
//	
	@Override
	public synchronized void withdrawFund() {
		
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		long temp,flag=1;
		while(flag!=0)
		{
		       temp=(long) balance;
			  	if(temp-amount>=500)
			       {
							temp=(long) (temp-amount);
							balance=temp;
							flag=0;
							
					}
				else
				{
					try
						{
							System.out.println("Insufficient balance "+
						Thread.currentThread().getName()+" is waiting");
							wait();//this is called and the chance is given to deposit
						}
						catch(InterruptedException ie)
						{
							ie.printStackTrace();
						}
				}
		}
		System.out.println("Withdraw is completed by "+
		Thread.currentThread().getName());
		System.out.println("Balance after withdraw is="+balance);
	}	
	

	@Override
	public void depositeFund() {
		 System.out.print("Amount to deposit: ");
	   	 @SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
	        amount = in.nextFloat();

	        if (amount <= 0)

	             System.out.println("Can't deposit nonpositive amount.");

	        else {

	             balance += amount;

	             System.out.println("$" + amount + " has been deposited.");

	        }

		
	}

	@Override
	public void provideStatement() {
		// TODO Auto-generated method stub
		
	}

}
