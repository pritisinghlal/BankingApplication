package com.mybankingapp;

public class ProfessioInformation {

	private String salaried;
	private String retired;
	private String businessman;
	
	
	public String getSalaried() {
		return salaried;
	}
	public void setSalaried(String salaried) {
		this.salaried = salaried;
	}
	public String getRetired() {
		return retired;
	}
	public void setRetired(String retired) {
		this.retired = retired;
	}
	public String getBusinessman() {
		return businessman;
	}
	public void setBusinessman(String businessman) {
		this.businessman = businessman;
	}
	
	
	
	
}
