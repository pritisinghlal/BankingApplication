package com.mybankingapp;

public interface Bank {
	public void transferFund();
	public void withdrawFund();
	public void depositeFund();
	public void provideStatement();

}
